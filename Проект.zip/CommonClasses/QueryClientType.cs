﻿using System;

namespace CommonClasses
{
    [Serializable]
    public enum QueryClientType
    {
        Connect,
        DataSend1
    }
}
