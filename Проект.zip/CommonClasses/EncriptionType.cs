﻿using System;

namespace CommonClasses
{
    [Serializable]
    public enum EncriptionType
    {
        Xor,
        Rsa
    }
}
